# TST-CafeLink API

A simple API for TST-CafeLink with authentication via Google OAuth using Supabase.

## Features
- Login with Google OAuth
- API Key authentication

## Getting Started
1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/TST-CafeLink.git
   cd TST-CafeLink
